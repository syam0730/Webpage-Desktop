    var topNum = 0,
        leftNum = 0;
      function moveleft() {
        leftNum -= 10;
        document.getElementById("ball").style.marginLeft = leftNum + "px";
      }

      function moveright() {
        leftNum += 10;
        document.getElementById("ball").style.marginLeft = leftNum + "px";
      }

      function moveup() {
        topNum -= 10;
        document.getElementById("ball").style.marginTop = topNum + "px";
      }

      function movedown() {
        topNum += 10;
        document.getElementById("ball").style.marginTop = topNum + "px";
      }
        